import requests
import pandas as pd
import datetime
import io
import flask
from flask import Flask, request
import json
import base64
from google.cloud import storage
from unicodedata import normalize, combining
from re import sub

app = flask.Flask(__name__)

# ===============================
# Configuração do Google Cloud Storage (GCS)
# ===============================
BUCKET_NAME = "bovespa-dados-brutos"  # Substitua pelo nome do seu bucket no GCS
GCS_PATH = "bovespa_raw/"  # Caminho dentro do bucket

# Inicializa o cliente do GCS (sem necessidade de credenciais externas no Cloud Run)
storage_client = storage.Client()

# ===============================
# API da B3 - IBOVESPA
# ===============================
LINK_API_IBOV = "https://sistemaswebb3-listados.b3.com.br/indexProxy/indexCall/GetPortfolioDay/"
SEGMENTO_CONSULTAR_POR_SETOR_ATUACAO = 2

class MLET4:
    def normalizarTexto(self, pString: str, pSubstituirEspaco: str = '_') -> str:
        vStringNormalizada = normalize('NFKD', pString)
        vStringNormalizada = sub('[^A-Za-z0-9_ ]', '', vStringNormalizada)
        vStringNormalizada = vStringNormalizada.strip().upper().replace(' ', '><').replace('<>', '').replace('><', pSubstituirEspaco)
        vStringNormalizada = ''.join([c for c in vStringNormalizada if not combining(c)])
        return vStringNormalizada

def payload_2_base64(pPayload_Dict: dict) -> str:
    vPayload_Json = json.dumps(pPayload_Dict)
    vPayload_base64 = base64.b64encode(vPayload_Json.encode()).decode()
    return vPayload_base64

def empresas_IBOV():
    """Faz o request na API da B3 e retorna os dados formatados."""
    vPayload = {
        "language": "pt-br",
        "pageNumber": 1,
        "pageSize": 100,
        "index": "IBOV",
        "segment": SEGMENTO_CONSULTAR_POR_SETOR_ATUACAO
    }
    vLinkAPI = LINK_API_IBOV + payload_2_base64(vPayload)
    response = requests.get(vLinkAPI)

    if response.status_code != 200:
        raise Exception(f"Erro ao acessar API da B3: {response.status_code}")

    json_resp = response.json()
    return json_resp.get("results", []), json_resp.get("header", [])

def salvar_no_gcs(pDataFrame: pd.DataFrame):
    """Salva o DataFrame no Google Cloud Storage (GCS) em formato Parquet."""
    bucket = storage_client.bucket(BUCKET_NAME)

    # Nome do arquivo com partição por data
    data_referencia = pDataFrame["DT_REFERENCIA_CARTEIRA"].max()
    data_extracao = pDataFrame["DT_EXTRACAO"].max().replace(":", "").replace("-", "").replace(" ", "_")
    file_name = f"{GCS_PATH}data={data_referencia}/Empresas_IBOV_{data_referencia}_{data_extracao}.parquet"

    # Convertendo o DataFrame para Parquet
    buffer = io.BytesIO()
    pDataFrame.to_parquet(buffer, engine="pyarrow")
    buffer.seek(0)

    # Upload para o GCS
    blob = bucket.blob(file_name)
    blob.upload_from_file(buffer, content_type="application/octet-stream")

    print(f"✅ Arquivo salvo com sucesso no GCS: gs://{BUCKET_NAME}/{file_name}")

@app.route("/", methods=["GET"])
def scrape_b3(request):
    """Endpoint HTTP para iniciar o scraping e salvar no GCS."""
    try:
        empresas, cabecalho = empresas_IBOV()
        if not empresas:
            return "❌ Nenhum dado retornado pela API da B3.", 500

        # Criar DataFrame
        vBase = pd.DataFrame(empresas)
        vBase["DT_REFERENCIA_CARTEIRA"] = int(pd.to_datetime(cabecalho["date"], format="%d/%m/%y").strftime("%Y%m%d"))
        vBase["DT_EXTRACAO"] = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

        # Renomear colunas
        vBase.rename(columns={
            "segment": "nme_setor",
            "cod": "cod_empresa",
            "asset": "nme_acao",
            "type": "dsc_tipo",
            "part": "val_participacao_setor",
            "partAcum": "val_participacao_acumulada_setor",
            "theoricalQty": "qtd_teorica"
        }, inplace=True)

        # Normalizar nomes das colunas
        u = MLET4()
        vBase.columns = [u.normalizarTexto(i) for i in vBase.columns]

        # Salvar no GCS
        salvar_no_gcs(vBase)

        return "✅ Dados coletados e armazenados com sucesso!", 200
    except Exception as e:
        return f"❌ Erro no processamento: {str(e)}", 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
